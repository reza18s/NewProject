import { AddProfilePage } from "@/components/forms/AddProfilePage";

function AddProfile() {
  return <AddProfilePage />;
}

export default AddProfile;
