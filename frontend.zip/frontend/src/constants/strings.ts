const categories = {
  apartment: "آپارتمان",
  villa: "ویلا",
  store: "مغازه",
  office: "دفتر",
};

export { categories };
